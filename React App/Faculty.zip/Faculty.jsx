function Faculty(props) {
    return(
        <div>
            <h2>Faculty Details</h2>
            <p>Name : {props.name}</p>
            <p>Subject : {props.subject}</p>
            <p>Experience : {props.experience} years</p>
        </div>
    );
}
export default Faculty;