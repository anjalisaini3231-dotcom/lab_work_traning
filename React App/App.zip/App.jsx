import Faculty from "./Faculty.jsx";
function App(){
  return(
    <div>
      <Faculty name="Ramesh" subject="Java" experience="13"/>
    </div>
  );
}
export default App;